﻿using System;

namespace WNS
{
    class Program
    {
        static void Main(string[] args)
        {
            Wizard wizard1 = new Wizard();
            Ninja ninja1 = new Ninja();
            samurai sam1 = new samurai();
            Zombie zom1 = new Zombie();
            Zombie zom2 = new Zombie();
            Spider spider = new Spider();
            int encounter =1;
            Console.WriteLine("A Zombie has appeared and attacked!!");
            while(encounter == 1){
                Console.WriteLine("Please type your attack below: ");
                string Inputline = Console.ReadLine();
                if(Inputline == "Ninja Steal"){
                    ninja1.Steal(zom1);
                    if(zom1.health > 0){
                        zom1.Feed(ninja1);

                    }else{
                        encounter = 0;
                        Console.WriteLine("The Zombies Health is gone YOU WIN!!");
                    }
                }
                if(Inputline == "Ninja Attack"){
                    ninja1.attack(zom1);
                    if(zom1.health > 0){
                        zom1.Feed(ninja1);

                    }else{
                        encounter = 0;
                        Console.WriteLine("The Zombies Health is gone YOU WIN!!");
                    }
                }
                if(Inputline == "Ninja run"){
                    ninja1.get_away();
                    if(ninja1.health > 0){
                    Console.WriteLine("The ninja got away");
                    encounter = 0;
                    }
                }
                if(ninja1.health <= 0){
                        encounter =0;
                        Console.WriteLine("The Ninja's Health is gone GAME OVER");
                }
            }
        }
    }
}
